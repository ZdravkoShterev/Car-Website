
        
        hamburger = document.querySelector(".hamburger");
        nav = document.querySelector("nav");
        hamburger.onclick = function() {
            nav.classList.toggle("active");
        }

        document.addEventListener("DOMContentLoaded", function() {
            const loadMoreButton = document.getElementById("load-more-btn");
            const items = document.querySelectorAll(".item");
            let visibleItemCount = 8; // Начален брой видими елементи
            
            // Функция, която показва или скрива елементите в зависимост от тяхното състояние
            function toggleItemsVisibility() {
                items.forEach((item, index) => {
                    if (index < visibleItemCount) {
                        item.style.display = "block";
                    } else {
                        item.style.display = "none";
                    }
                });
            }
            
            // При натискане на бутона, увеличаваме броя на видимите елементи и извикваме функцията за промяна на видимостта
            loadMoreButton.addEventListener("click", function() {
                visibleItemCount += 8; // Увеличаваме броя на видимите елементи с 6
                toggleItemsVisibility(); // Променяме видимостта на елементите
            });
            
            // Инициализираме първоначалната видимост на елементите
            toggleItemsVisibility();
        });
        